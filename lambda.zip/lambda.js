exports.handler = async (event) => {
  const response = {
    statusCode: 200,
    body: 'Hello, world!'
  };
  return response;
};
